import { AppRegistry } from 'react-native';
import App from './src/main';

AppRegistry.registerComponent('carBooking', () => App);